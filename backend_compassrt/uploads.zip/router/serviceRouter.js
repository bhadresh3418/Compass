const express = require("express")
const router = express.Router()

const liveDataController = require("../src/controller/liveDataController")

router.get("/getData",liveDataController.getData);

module.exports = router