exports.getData = async (req, res) => {
    try {
        return res.status(200).json({
            data: "data is here",
            success: true,
        })
    }catch(e){
        return res.status(400).json({
            error: error.message,
            success: false,
        });
    }
}